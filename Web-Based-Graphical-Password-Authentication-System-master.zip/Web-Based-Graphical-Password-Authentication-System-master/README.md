# Web-Based-Graphical-Password-Authentication-System
Web Based Graphical Password Authentication System is a web based application that can be used in any system to allow users to sign up and log in using a different model other than the static passwords. 

In normal authentication systems, static passwords are used by users to get in the system but it is a known fact that static passwords are very easy to hack. Thus in this system, a user can select certain points in an image and use them as their password. They are immune to basic hacking techniques like brute force attack &amp; dictionary attacks.

This project was developed using:
Apache Tomcat 7.0.81, SQLite 3.17.0, HTML, CSS, JavaScript, jQuery & Gmail API.
Browser Used: Chrome 62.0.3202
